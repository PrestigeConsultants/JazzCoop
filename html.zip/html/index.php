<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>


<body>
	<div class="container-fluid">

		<?php include 'include/navbar.php'; ?>

		<div class="jumbotron bg-dark text-white">
		  <h1 class="display-4">Demo</h1>
		  <p class="lead">This is a demo.</p>
		  <hr class="my-4">
		  <p>Created March 2018</p>
		  <p class="lead">
		    <a class="btn btn-danger btn-lg" href="#" role="button">Learn more</a>
		  </p>
		</div>

	</div>
	
</body>
</html>