<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>


<body>

<?php include 'include/connectdb.php'; ?>

<?php $sql = "SELECT id, name FROM event ORDER BY name ASC";
      $eventResult = $conn->query($sql);
?>








<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Create New Staff</h1>

    <br><br>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

        <div class="container-fluid">
            <div class="row">
                <div class="col-2">
                    Firstname:
                </div>
                <div class="col-8">
                    <input type="text" name="FirstName"><br>
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Surname:
                </div>
                <div class="col-8">
                    <input type="text" name="Surname"><br>
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Type:
                </div>
                <div class="col-8">
                    <select name="empType">
                        <option value=""></option>
                        <option value="Paid">Paid</option>
                        <option value="Volunteer">Volunteer</option>
                    </select>

                    <br>

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Event ID: 

                </div>
                <div class="col-8">
                    <select name="EventID">
                        <option value="0"></option>

                        <?php 

                        if ($eventResult->num_rows > 0) {
                            // output data of each row
                                while($row = $eventResult->fetch_assoc()) {
                        

                                    echo "<option value=\"". $row["id"] ."\">" . $row["name"] . "</option>";

                    
                        
                                }
                            }
                        ?>
                    </select>

                        

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Date:
                </div>
                <div class="col-8">
                    <input type="date" name="Date"><br>
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Start Time:
                </div>
                <div class="col-8">
                    <input type="text" name="Start"><br>
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    End Time:
                </div>
                <div class="col-8">
                    <input type="text" name="End"><br>
                </div>
            </div>


            <input type="hidden" name="myAction" value="createAction">
            <input type="submit" class="btn btn-danger" value="Create">
        </div>

    </form>

    <?php

         if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["myAction"] == "createAction") {
              $firstName = test_input($_POST["FirstName"]);
              $surname   = test_input($_POST["Surname"]);
              $empType   = test_input($_POST["empType"]);
              $date      = test_input($_POST["Date"]);
              $startTime = test_input($_POST["Start"]);
              $endTime   = test_input($_POST["End"]);
              $eventID   = test_input($_POST["EventID"]);

    


                  $sql = "INSERT INTO staff (Firstname, Surname, empType, Date, Start, End, EventID) 
                          VALUES ('" . $firstName . "','" . $surname . "','" . $empType . "','" . $date . "','" . $startTime . "','" . $endTime . "','". $eventID ."')";


               if (mysqli_query($conn, $sql)) {
                    echo "New record created successfully";
                }
                else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

                }

            }
             mysqli_close($conn);

         ?>


     </div>

  </body>
