<?php

echo "
		<nav class=\"navbar navbar-expand-lg navbar-dark bg-danger\">
		  <a class=\"navbar-brand\" href=\"index.php\">JazzDemo</a>
		  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
		    <span class=\"navbar-toggler-icon\"></span>
		  </button>

		  <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
		    <ul class=\"navbar-nav mr-auto\">
		  	   		      
		      <div class=\"nav-item dropdown\">
		        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
		          Staff
		        </a>
		        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
		          <a class=\"dropdown-item\" href=\"staff.php\">List Staff</a>
		          <a class=\"dropdown-item\" href=\"staffNew.php\">Create Staff</a>
		        </div>
		      </div>
		      
		      <div class=\"nav-item dropdown\">
		        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
		          Events
		        </a>
		        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
		          <a class=\"dropdown-item\" href=\"events.php\">List Event</a>
		          <a class=\"dropdown-item\" href=\"eventsNew.php\">Create Event</a>
		        </div>
		      </div>
		      
		      <div class=\"nav-item dropdown\">
		        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
		          Promotion
		        </a>
		        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
		          <a class=\"dropdown-item\" href=\"promotion.php\">List Promotion</a>
		          <a class=\"dropdown-item\" href=\"promotionNew.php\">Create Promotion</a>
		        </div>
		      </div>
		     		      		      
		      <li class=\"nav-item dropdown\">
		        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
		          Reports
		        </a>
		        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
		          <a class=\"dropdown-item\" href=\"eventfinance.php\">Event Finance</a>
		          <a class=\"dropdown-item\" href=\"completefinance.php\">Complete Finance</a>
		        </div>
		      </li>
		     </ul>
		     
		     
		     
		     
		    <form class=\"form-inline my-2 my-lg-0\" method=\"post\" action=\" "
    . htmlspecialchars($_SERVER["PHP_SELF"]) . "  \">
		      <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\" name=\"mySearch\">
		      <input type=\"hidden\" name=\"myAction\" value=\"searchaction\">
		      <button class=\"btn btn-outline-light my-2 my-sm-0\" type=\"submit\">Search</button>
		    </form>
		  </div>
		</nav>
	";


$search = "You searched: ";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["myAction"] == "searchaction") {
        $search = test_input($_POST["mySearch"]);
        echo "	<br>
						<div class=\"alert alert-danger\" role=\"alert\">
							Your search: " . $search . " 
							<h3>No results</h3>
							(... but search isn't implemented yet!)
						</div>";
    }

}


?>