<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>

<body>

	<div class="container-fluid">

		<p>Nothing here</p>

	</div>
	
</body>
</html>