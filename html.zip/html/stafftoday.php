<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php';?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Staff On Shift Today</h1>

    <div class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Filter Events
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="staff.php">All Staff</a>
            <a class="dropdown-item" href="stafftoday.php">Staff Today</a>
            <a class="dropdown-item" href="staffweek.php">Staff This Week</a>
            <a class="dropdown-item" href="staffmonth.php">Staff This Month</a>
        </div>
    </div>

    <div class="row">

        <?php
        $sql = "SELECT * FROM staff LEFT JOIN event on (EventID = ID) WHERE DATE(staff.Date) = DATE(NOW()) ORDER BY staff.Date ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {

                $price = $row["price"]/100;

                echo "						
								<div class=\"col-sm-4\">
								<div class=\"card\">
									<div class=\"card-header bg-dark text-white\" >". $row["Firstname"] . " " . $row["Surname"] ."</div>
							 		<div class=\"card-body bg-secondary text-white\">
						     			<p class=\"card-text\">Employee type: " . $row["empType"] . "</p>
						     			<p class=\"card-text\">Date: " . $row["Date"] . "</p>
						     			<p class=\"card-text\">Start Time: " . $row["Start"] . "</p>
						     			<p class=\"card-text\">End Time: " . $row["End"] . "</p>
						     			<p class=\"card-text\">Name of Event: " . $row["Name"] . "</p>
						     		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

            }
        } else {
            echo "No staff on shift today";
        }
        $conn->close();
        ?>


    </div>
</div>
</body>
</html>