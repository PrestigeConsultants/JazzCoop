<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php';?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Promotions</h1>

     <div class="row">

        <?php
        $sql = "SELECT * FROM promotion";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {



                echo "
                        <div class=\"col-sm-4 py-3\">
							<div class=\"card h-100\">
							   <div class=\"card-header bg-dark text-white\" >" . $row["EventName"] . "</div>
							 		<div class=\"card-body bg-secondary text-white\">
							 		    <p class=\"card-text\">Facebook: " . $row["Facebook"] . "</p>
							 		    <p class=\"card-text\">Line up now: " . $row["LineUpNow"] . "</p>
							 		    <p class=\"card-text\">Globe Flyer: " . $row["GlobeFlyer"] . "</p>
							 		    <p class=\"card-text\">Jazzwise Magazine: " . $row["JazzwiseMagazine"] . "</p>
							 		    <p class=\"card-text\">Listoria: " . $row["Listoria"] . "</p>
							 		    <p class=\"card-text\">Simply What's On: " . $row["SimplyWhatsOn"] . "</p>
							 		    <p class=\"card-text\">Folk Roots List: " . $row["FolkRootsList"] . "</p>
							 		    <p class=\"card-text\">Folk and Roots: " . $row["FolkandRoots"] . "</p>
							 		    <p class=\"card-text\">The List: " . $row["TheList"] . "</p>
							 		    <p class=\"card-text\">Newcastle Gateshead: " . $row["NewcsatleGateshead"] . "</p>
							 		    <p class=\"card-text\">The Crack: " . $row["TheCrack"] . "</p>
							 		    <p class=\"card-text\">Get into Newcastle: " . $row["GetIntoNewcastle"] . "</p>
							 		    <p class=\"card-text\">Jazz Near You: " . $row["JazzNearYou"] . "</p>
							 		    <p class=\"card-text\">NARC: " . $row["NARC"] . "</p>
						     		</div>
							 	</div>
							 	<br>
						 	</div>
						";

            }
        } else {
            echo "0 results";
        }

        $conn->close();
        ?>


    </div>
</div>
</body>
</html>