<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>


<body>

<?php include 'include/connectdb.php'; ?>
<?php $sql = "SELECT id, name FROM event ORDER BY name ASC";
      $eventResult = $conn->query($sql);
?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Promotion</h1>

    <br><br>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

        <div class="container-fluid">
            <div class="row">
                <div class="col-2">
                    Event name:
                </div>
                <div class="col-8">
                    <select name="name">
                        <option value="0"></option>

                        <?php 

                        if ($eventResult->num_rows > 0) {
                            // output data of each row
                                while($row = $eventResult->fetch_assoc()) {
                        

                                    echo "<option value=\"". $row["name"] ."\">" . $row["name"] . "</option>";

                    
                        
                                }
                            }
                        ?>
                    </select>
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Facebook:
                </div>
                <div class="col-8">
                    <input type="text" name="facebook">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Line-up now:
                </div>
                <div class="col-8">
                    <input type="text" name="lineupnow">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Globe flyer:
                </div>
                <div class="col-8">
                    <input type="text" name="globeflyer">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Jazzwise Magazine:
                </div>
                <div class="col-8">
                    <input type="text" name="jazzwisemagazine">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Listoria:
                </div>
                <div class="col-8">
                    <input type="text" name="listoria">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Simply What's On:
                </div>
                <div class="col-8">
                    <input type="text" name="simplywhatson">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Folk Roots List:
                </div>
                <div class="col-8">
                    <input type="text" name="folkrootslist">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Folk and Roots:
                </div>
                <div class="col-8">
                    <input type="text" name="folkandroots">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    The List:
                </div>
                <div class="col-8">
                    <input type="text" name="thelist">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Newcastle Gateshead:
                </div>
                <div class="col-8">
                    <input type="text" name="newcastlegateshead">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    The Crack:
                </div>
                <div class="col-8">
                    <input type="text" name="thecrack">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Get Into Newcastle:
                </div>
                <div class="col-8">
                    <input type="text" name="empType">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    Jazz Near You:
                </div>
                <div class="col-8">
                    <input type="text" name="jazznearyou">

                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-2">
                    NARC:
                </div>
                <div class="col-8">
                    <input type="text" name="narc">

                </div>
            </div>


            <input type="hidden" name="myAction" value="createAction">
            <input type="submit" name="submit" Value="Submit">


        </div>

    </form>

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["myAction"] == "createAction") {
        $name               = test_input($_POST["name"]);
        $facebook           = test_input($_POST["facebook"]);
        $lineupnow          = test_input($_POST["LineUpNow"]);
        $globeflyer         = test_input($_POST["globeflyer"]);
        $jazzwisemagazine   = test_input($_POST["jazzwisemagazine"]);
        $listoria           = test_input($_POST["listoria"]);
        $simplywhatson      = test_input($_POST["simplywhatson"]);
        $folkrootslist      = test_input($_POST["folkrootslist"]);
        $folkandroots       = test_input($_POST["folkandroots"]);
        $thelist            = test_input($_POST["thelist"]);
        $newcastlegateshead = test_input($_POST["newcastlegateshead"]);
        $thecrack           = test_input($_POST["thecrack"]);
        $getintonewcastle   = test_input($_POST["getintonewcastle"]);
        $jazznearyou        = test_input($_POST["jazznearyou"]);
        $narc               = test_input($_POST["narc"]);


    


    $sql = "INSERT INTO promotion (EventName, Facebook, LineUpNow, GlobeFlyer, JazzwiseMagazine, Listoria, SimplyWhatsOn, FolkRootsList, FolkandRoots, TheList, NewcastleGateshead, TheCrack, GetIntoNewcastle, JazzNearYou, NARC) 
                   VALUES ('" . $name . "','" . $facebook . "','" . $lineupnow . "','" . $globeflyer . "','" . $jazzwisemagazine . "','" . $listoria . "','" . $simplywhatson . "','" . $folkrootslist . "','" . $folkandroots . "','" . $thelist . "','" . $newcastlegateshead . "','" . $thecrack . "','" . $getintonewcastle . "','" . $jazznearyou . "','" . $narc . "')";


    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);

    }


	}

    mysqli_close($conn);



    ?>


</div>

</body>
</html>