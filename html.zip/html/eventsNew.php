<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>


<body>

<?php include 'include/connectdb.php'; ?>

	<div class="container-fluid">

<?php include 'include/navbar.php'; ?>

		<h1>Create New Event</h1>

		<br><br>

		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

			<div class="container-fluid">
			  	<div class="row">
			    	<div class="col-2">
			      		Event name: 
			    	</div>
			    	<div class="col-8">
			      		<input type="text" name="name"><br>
			    	</div>
			  	</div>

			  	<br>

                <div class="row">
                    <div class="col-2">
                        Type:
                    </div>
                    <div class="col-8">
                        <select name="Type">
                            <option value="-">-</option>
                            <option value="Private">Private</option>
                            <option value="Public">Public</option>
                        </select>

                        <br>
                    </div>
                </div>

                <br>

                <div class="row">
			    	<div class="col-2">
			      		Date: 
			    	</div>
			    	<div class="col-8">
			      		<input type="text" name="date"><br>
			    	</div>
			 	</div>

			 	<br>

			 	<div class="row">
			    	<div class="col-2">
			      		Price:
			    	</div>
			    	<div class="col-8">
			      		<input type="text" name="price"><br>
			    	</div>
				</div>

				<br>

                <div class="row">
                    <div class="col-2">
                        Start Time:
                    </div>
                    <div class="col-8">
                        <input type="time" name="StartTime"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        End Time:
                    </div>
                    <div class="col-8">
                        <input type="time" name="EndTime"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Location:
                    </div>
                    <div class="col-8">
                        <input type="text" name="Location"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Floor:
                    </div>
                    <div class="col-8">
                        <select name="Floor">
                        	<option value="-">-</option>
                        	<option value="Ground">Ground floor</option>
                        	<option value="First">First floor</option>
                   	 	</select>

                        	<br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Category:
                    </div>
                    <div class="col-8">
                        <select name="Category">
                        	<option value="-">-</option>
                        	<option value="Jazz">Jazz</option>
                        	<option value="Blues">Blues</option>
                        	<option value="Folk">Folk</option>
                        	<option value="Country">Country</option>
                        	<option value="Indie">Indie</option>
                        	<option value="Pop">Pop</option>
                        	<option value="Rock">Rock</option>
                        	<option value="Electronic">Electronic</option>
                   	 	</select>

                        	<br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Short Description:
                    </div>
                    <div class="col-8">
                        <textarea name="ShortDesc" rows="10" cols="50">Short description here</textarea>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Long Description:
                    </div>
                    <div class="col-8">
                        <textarea name="LongDesc" rows="20" cols="50">Long description here</textarea>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Performer Type:
                    </div>
                    <div class="col-8">
                        <select name="PerformerType">
                            <option value="-">-</option>
                            <option value="Band">Band</option>
                            <option value="Performer">Performer</option>
                            <option value="Booker">Booker</option>
                        </select>

                        <br>
                    </div>
                </div>

                <br>

                    <div class="row">
                        <div class="col-2">
                            Name Of Booker:
                        </div>
                        <div class="col-8">
                            <input type="text" name="NameOfBooker"><br>
                        </div>
                    </div>

                    <br>

                <div class="row">
                    <div class="col-2">
                        Phone Number: 
                    </div>
                    <div class="col-8">
                        <input name="Phone" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Email:
                    </div>
                    <div class="col-8">
                        <input name="Email" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Time for Setup:
                    </div>
                    <div class="col-8">
                        <input name="Setup" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Special Arrangements
                    </div>
                    <div class="col-8">
                        <input name="SpecialArrangements" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Hire Fee
                    </div>
                    <div class="col-8">
                        <input name="HireFee" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-2">
                        Deposit
                    </div>
                    <div class="col-8">
                        <input name="Deposit" rows="20" cols="8"><br>
                    </div>
                </div>

                <br>




				<input type="hidden" name="myAction" value="createAction">
				<input type="submit" class="btn btn-danger" value="Create">
			</div>

		</form>
		
		<?php

				if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["myAction"] == "createAction") {
						$name = test_input($_POST["name"]);
						$type = test_input($_POST["Type"]);
						$date = test_input($_POST["date"]);
						$price = test_input($_POST["price"]);
						$startTime = test_input($_POST["StartTime"]);
						$endTime = test_input($_POST["EndTime"]);
						$location = test_input($_POST["Location"]);
						$floor = test_input($_POST["Floor"]);
						$shortDesc = test_input($_POST["ShortDesc"]);
						$category = test_input($_POST["Category"]);
						$longDesc = test_input($_POST["LongDesc"]);
						$performertype = test_input($_POST["PerformerType"]);
						$nameofbooker = test_input($_POST["NameOfBooker"]);
						$phone = test_input($_POST["Phone"]);
					    $email = test_input($_POST["Email"]);
					    $setup = test_input($_POST["TimeForSetup"]);
					    $specialarrangements = test_input($_POST["SpecialArrangements"]);
					    $hirefee = test_input($_POST["HireFee"]);
					    $deposit = test_input($_POST["Deposit"]);




						if(filter_var($price, FILTER_VALIDATE_INT) === false){
  							echo "Price not an integer, set to 0<br>";
  							$price = 0;
						}


						$sql    = 	"INSERT INTO event (Name, Type, Price, Date, Time, Location, Category, Floor, ShortDesc, LongDesc, PerformerType, NameOfBooker, Phone, Email, TimeForSetup, SpecialArrangements, HireFee, Deposit) 
									VALUES ('" . $name . "','" . $type . "','" . $price. "','" .$date. "','" .$startTime. "','" .$location. "','" .$category. "','"  .$floor. "','" .$shortDesc. "','" .$longDesc. "', '" .$performertype. "','" .$nameofbooker. "','" .$phone. "','"  .$email. "','" .$setup. "','" .$specialarrangements. "', '" .$hirefee. "','" .$deposit. "')";

						if (mysqli_query($conn, $sql)) {
    						echo "New record created successfully";
						} else {
    						echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}
				}

				mysqli_close($conn);
			
		?>


	</div>
	
</body>
</html>