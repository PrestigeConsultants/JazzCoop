<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php';?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>More Detail</h1>

    <div class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Filter Events
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="events.php">All Events</a>
            <a class="dropdown-item" href="today.php">Events Today</a>
            <a class="dropdown-item" href="week.php">Events This Week</a>
            <a class="dropdown-item" href="month.php">Events This Month</a>
        </div>
    </div>

    <?php
    $sql = "SELECT * FROM event  WHERE DATE(date) >= DATE(NOW()) ORDER BY date ASC";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {

            $price = $row["price"]/100;

            echo "
							<div class=\"container-fluid\">
								<div class=\"card\">
									<div class=\"card-header bg-dark text-white\" >" . $row["Name"] . "</div>
							 		<div class=\"card-body bg-secondary text-white\"><h5 class=\"card-title\">" . $row["Type"] . "</h5>
						     			<p class=\"card-text\">Phone: +44" . $row["Phone"] . "</p>
						     			<p class=\"card-text\">Email: " . $row["Email"] . "</p>
						     			<p class=\"card-text\">Date: " . $row["Date"] . "</p>
						     			<p class=\"card-text\">Time For Setup: " . $row["TimeForSetup"] . "</p>
						     			<p class=\"card-text\">Special Arrangements: " . $row["SpecialArrangements"] . "</p>
						     			<p class=\"card-text\">Hire Fee: £" . $row["HireFee"] . "</p>
						     			<p class=\"card-text\">Deposit: £" . $row["Deposit"] . "</p>
						     			<p class=\"card-text\">Long Description: " . $row["LongDesc"] . "</p>
						     			
							 		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

        }
    } else {
        echo "0 results";
    }
    $conn->close();
    ?>


</div>

</body>
</html>