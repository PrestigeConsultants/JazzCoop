<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php';?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Events This Week</h1>

    <div class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Filter Events
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="events.php">All Events</a>
            <a class="dropdown-item" href="pastevents.php">Past Events</a>
            <a class="dropdown-item" href="today.php">Events Today</a>
            <a class="dropdown-item" href="week.php">Events This Week</a>
            <a class="dropdown-item" href="month.php">Events This Month</a>
        </div>
    </div>

    <div class="row">

    <?php
    $sql = "SELECT id, name, price, date, time, location, category, floor, shortdesc FROM event WHERE WEEKOFYEAR(date) = WEEKOFYEAR(NOW())";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {

            $price = $row["price"]/100;

            echo "
						<div class=\"col-sm-4 py-3\">
							<div class=\"card h-100\">
									<div class=\"card-header bg-dark text-white\" >" . $row["name"] . "</div>
							 		<div class=\"card-body bg-secondary text-white\">
							 			<p class=\"card-text\">" . $row["date"] . " (" . $row["time"] . ")</p>
						     			<p class=\"card-text\">Ticket price: £" . $price . "</p>
						     			<p class=\"card-text\">Location: " . $row["location"] . "</p>
						     			<p class=\"card-text\">Category: " . $row["category"] . "</p>
						     			<p class=\"card-text\">Floor: " . $row["floor"] . "</p>
						     			<p class=\"card-text\">Short Description:    "   . $row["shortdesc"] . "</p>
						     			<p><a class=\"btn btn-danger btn-lg\" href=\"moredetail.php\" role=\"button\">Learn more</a></p> 
							 		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

        } RETURN true;
    } else {
        echo "0";
    }
    $conn->close();
    ?>


</div>
</div>

</body>
</html>