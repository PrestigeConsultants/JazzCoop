<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php'; ?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Event Finance</h1>

    <?php
    $sql    = "SELECT EventID, NameOfEvent, NoCustomers, TicketSales, BarSales, HireFee, BarStaff, DoorStaff, PerformerFee, Overall FROM eventfinance ORDER BY Overall DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {

            echo "
							<div class=\"container-fluid\">
								<div class=\"card\">
									<div class=\"card-header bg-dark text-white\" >" . $row["NameOfEvent"] . "</div>
							 		<div class=\"card-body bg-secondary text-white\"><h5 class=\"card-title\">Number of Customers: " . $row["NoCustomers"] . "</h5>
						     			<p class=\"card-text\">Ticket Sales:  £" . $row["TicketSales"] . "</p>
						     			<p class=\"card-text\">Bar Sales:  £" . $row["BarSales"] . "</p>
						     			<p class=\"card-text\">Hire Fee:  £" . $row["HireFee"] . "</p>
						     			<p class=\"card-text\">Bar Staff:  £" . $row["BarStaff"] . "</p>
						     			<p class=\"card-text\">Door Staff:  £" . $row["DoorStaff"] . "</p>
						     			<p class=\"card-text\">Performer Fee:  £" . $row["PerformerFee"] . "</p>
						     			<p class=\"card-text\"><strong>Overall: £" . $row["Overall"] . "</strong></p>
							 		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

        }
    }
    else {
        echo "0 results";
    }
    $conn->close();
    ?>


</div>

</body>
</html>