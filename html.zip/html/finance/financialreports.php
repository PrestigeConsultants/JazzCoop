<!DOCTYPE HTML>
<html>

<?php include '../include/head.php'; ?>
<?php include '../include/lib.php'; ?>

<body>

	<?php include '../include/connectdb.php';?>

	<div class="container-fluid">

		<?php include '../include/navbar.php'; ?>

		<h1>Finance</h1>

		<?php
			$sql = "SELECT ID, Current, Target, Overall FROM finance";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
			    // output data of each row
			    while($row = $result->fetch_assoc()) {


					echo "
							<div class=\"container-fluid\">
								<div class=\"card\">
									<div class=\"card-header bg-primary text-white\" >Finance " . $row["ID"] . "</div>
							 		<div class=\"card-body bg-light\">
							 			
							 			<p class=\"card-text\">" . $row["Current"] . " (" . $row["Target"] . ")</p>
						     			<p class=\"card-text\">" . $row["Overall"] . "</p>
							 		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

			    }
			} else {
			    echo "0 results";
			}
			$conn->close();
		?>


	</div>
	
</body>
</html>