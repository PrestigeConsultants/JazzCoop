<!DOCTYPE HTML>
<html>

<?php include 'include/head.php'; ?>
<?php include 'include/lib.php'; ?>

<body>

<?php include 'include/connectdb.php'; ?>

<div class="container-fluid">

    <?php include 'include/navbar.php'; ?>

    <h1>Booking</h1>

    <div class="row">

    <?php
    //$sql    = "SELECT CustomerID, Type, Name, Phone, Email, Date, TimeForSetup, SpecialArrangements, HireFee, Deposit, EventType FROM booking";

    $sql = "SELECT * \n"
        . "FROM booking\n"
        . "JOIN event ON ID=CustomerID";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {

            echo "
						 <div class=\"col-sm-4 py-3\">
							<div class=\"card h-100\">
									<div class=\"card-header bg-dark text-white\" > " . $row["Name"] . "</div>
							 		<div class=\"card-body bg-secondary text-white\"><h5 class=\"card-title\">" . $row["Type"] . "</h5>
						     			<p class=\"card-text\">Phone:  +44" . $row["Phone"] . "</p>
						     			<p class=\"card-text\">Email: " . $row["Email"] . "</p>
						     			<p class=\"card-text\">Date: " . $row["Date"] . "</p>
						     			<p class=\"card-text\">Time For Setup: " . $row["TimeForSetup"] . "</p>
						     			<p class=\"card-text\">Special Arrangements: " . $row["SpecialArrangements"] . "</p>
						     			<p class=\"card-text\">Hire Fee: £" . $row["HireFee"] . "</p>
						     			<p class=\"card-text\">Deposit: £" . $row["Deposit"] . "</p>
						     			<p class=\"card-text\">Event Type: " . $row["EventType"] . "</p>
						     			<p class=\"card-text\">Long Description: " . $row["LongDesc"] . "</p>
						     			
							 		</div>
							 	</div>
							 	<br>
						 	</div>
						 ";

        }
    }
    else {
        echo "0 results";
    }
    $conn->close();
    ?>


</div>

</body>
</html>